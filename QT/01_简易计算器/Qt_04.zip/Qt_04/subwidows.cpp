#include "subwidows.h"

Subwidows::Subwidows(QWidget *parent) : QWidget(parent)
{

}
