#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include<QPushButton>//按钮
#include"subwindows.h"//子窗口头文件
class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();

    void mySs();
    void qie();
    void chulizi();

private:
    QPushButton b1;
    QPushButton *b2;
     QPushButton b3;

     SubWindows w;

};
#endif // MAINWIDGET_H
