//构造函数
#include "mainwidget.h"

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
{
    b1.setParent(this);
    b1.setText("b1   关闭");
    b1.move(100,100);

    b2=new QPushButton(this);
    b2->setText("b2");
    b2->move(200,200);
    //                                 影响谁
 //处理信号   谁发               类型 改变 改变谁            具体改变
    connect(&b1,&QPushButton::pressed,this,&MainWidget::close);
    /*
     * &b1    ：信号发出者，指针类型
     * &QPushButton::pressed    ：处理的信号    &发送者的类名：：信号名字
     * this ：信号接收者
     * &MainWidget::close   ：槽函数，信号处理函数    &接收信号的类名：：槽函数名字
     */

    /*
     * 自定义槽函数，普通函数的用法
     *Qt5:任意的成员函数，普通全局函数，静态函数
     *槽函数需要和信号一致（参数、返回值）
     *由于信号都是没有返回值，所以，槽函数一定没有返回值
     */
    connect(b2,&QPushButton::released,this,&MainWidget::mySs);

    setWindowTitle("老大");
    //this->setWindowTitle("老大");
     b3.setParent(this);
     b3.setText("切换到子窗口");
     b3.move(300,300);

     connect(&b3,&QPushButton::released,this,&MainWidget::qie);

     //处理子窗口的信号
     connect(&w,&SubWindows::qiehui,this,&MainWidget::chulizi);


    resize(1000,800);


}

void MainWidget::mySs()
{
b2->setText("b2222222222222");
}

void MainWidget::qie()
{
    //子窗口显示
    w.show();

    //父窗口隐藏
    this->hide();
}

void MainWidget::chulizi()
{
    this->show();

    w.hide();
}

MainWidget::~MainWidget()
{

}

