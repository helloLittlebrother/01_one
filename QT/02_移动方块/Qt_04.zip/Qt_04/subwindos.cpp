#include "subwindos.h"

SubWindos::SubWindos(QWidget *parent) : QWidget(parent)
{

}
