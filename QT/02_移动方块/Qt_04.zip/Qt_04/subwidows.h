#ifndef SUBWIDOWS_H
#define SUBWIDOWS_H

#include <QWidget>

class Subwidows : public QWidget
{
    Q_OBJECT
public:
    explicit Subwidows(QWidget *parent = nullptr);

signals:

};

#endif // SUBWIDOWS_H
