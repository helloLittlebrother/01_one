#ifndef SUBWINDOS_H
#define SUBWINDOS_H

#include <QWidget>

class SubWindos : public QWidget
{
    Q_OBJECT
public:
    explicit SubWindos(QWidget *parent = nullptr);

signals:

};

#endif // SUBWINDOS_H
