#include "kk_01.h"
#include "ui_kk_01.h"

kk_01::kk_01(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::kk_01)
{
    ui->setupUi(this);
}

kk_01::~kk_01()
{
    delete ui;
}
