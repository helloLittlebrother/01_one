#include "kkk_01.h"

kkk_01::kkk_01(QWidget *parent) : QWidget(parent)
{

}
