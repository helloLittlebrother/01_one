#include "ss_002.h"
#include <QThread>
#include<QDebug>
#include <synchapi.h>

ss_002::ss_002(QObject *parent):QThread(parent)
{

    //
}
void ss_002::run(){

    int aaaaa=1101;
    qDebug() << aaaaa;
        //监听套接字
        tcpServer=new QTcpServer(this);    //this  指定父对象，让其自动回收空间
        tcpServer->listen(QHostAddress::Any,8888);

        connect(tcpServer,&QTcpServer::newConnection,
                [=]()
                {
                    //取出建立好连接的套接字
                    tcpSocket =tcpServer->nextPendingConnection();

                    connect(tcpSocket,&QTcpSocket::readyRead,
                            [=]()
                    {
                        QByteArray array=tcpSocket->readAll();//取
                        emit bian002(array);
                        tcpSocket->write(array);//发
                    });
                }
                );



Sleep(1000);
       while(1){Sleep(1000);}
}

void ss_002::bianbian2(QByteArray array){
    tcpSocket->write(array);//发
}
