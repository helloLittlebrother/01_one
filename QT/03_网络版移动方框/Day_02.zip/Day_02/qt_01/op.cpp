#include "op.h"
#include<QHostAddress>
op::op(QWidget *parent) : QWidget(parent)
{
    tcpSocket=NULL;
    tcpSocket = new QTcpSocket(this);
    QString asa="123";
    tcpSocket->connectToHost(QHostAddress(asa),8800);
}
