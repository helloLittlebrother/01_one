#ifndef SS_002_H
#define SS_002_H
#include"ss_001.h"
#include<QTcpServer>//监听套接字
#include<QTcpSocket>//通信套接字
#include<Qthread>

class ss_002 :public QThread
{
    Q_OBJECT
public:
    explicit ss_002(QObject *parent = nullptr);
    void bianbian2(QByteArray);
protected:
    void run();
signals:
    void bian002(QByteArray);
private:
    QTcpServer *tcpServer;//监听套接字
    QTcpSocket *tcpSocket;//通信套接字

};

#endif // SS_001_H
