#include "ss_1.h"

ss_1::ss_1(QWidget *parent) : QWidget(parent)
{

}
