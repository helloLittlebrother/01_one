#include "k_1.h"

k_1::k_1(QWidget *parent) : QWidget(parent)
{

}
