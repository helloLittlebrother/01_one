
#ifndef K1_H
#define K1_H
#include <QApplication>
#include <iostream>
#include <thread>
#include<QThread>

#include<QPushButton>//按钮


#include<QPainter>
#include <QWidget>
#include<QTcpSocket>
class k1 : public QWidget
{
    Q_OBJECT
public:
     k1(QWidget *parent = nullptr);

private:
   QTcpSocket *tcpSocket;
   QPainter painter;
   void paintEvent(QPaintEvent *);
   QPainter *paint;
   QPainter *paint1;


protected:
     void keyPressEvent(QKeyEvent *);
};

#endif // K1_H
