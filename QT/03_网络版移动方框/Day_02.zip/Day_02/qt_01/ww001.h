#ifndef WW001_H

#include <QWidget>
#include <QApplication>
#include <iostream>
#include <thread>
#include<QThread>

#include<QPushButton>//按钮

#include<QPainter>
#include"QTcpSocket"

class ww001 : public QWidget
{
    Q_OBJECT
public:
    explicit ww001(QWidget *parent = nullptr);
private:
    //自己动+画图
    QPainter painter;
    void paintEvent(QPaintEvent *);
    QPainter *paint;
    QPainter *paint1;
    QTcpSocket *tcpSocket;
    //void paintEvent(QPaintEvent *);
protected:


     //画图的
     void keyPressEvent(QKeyEvent *);

};

#endif // WW001_H
