#ifndef K_1_H
#define K_1_H

#include <QWidget>

class k_1 : public QWidget
{
    Q_OBJECT
public:
    explicit k_1(QWidget *parent = nullptr);

signals:

};

#endif // K_1_H
