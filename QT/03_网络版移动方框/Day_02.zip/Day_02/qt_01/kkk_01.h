#ifndef KKK_01_H
#define KKK_01_H

#include <QWidget>

class kkk_01 : public QWidget
{
    Q_OBJECT
public:
    explicit kkk_01(QWidget *parent = nullptr);

signals:

};

#endif // KKK_01_H
