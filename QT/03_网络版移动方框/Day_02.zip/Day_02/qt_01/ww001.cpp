#include "ww001.h"
//构造函数
#include<QHostAddress>

#include<QDebug>
#include <iostream>
#include <thread>
#include<windows.h>
#include<QPainter>
#include<QThread>

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<QKeyEvent>
int sa=0;
int sb=50;
int sc=300;
int sd=50;
int se=250;
int sf=250;
ww001::ww001(QWidget *parent) : QWidget(parent)
{
    int qwe=1111;
    tcpSocket=NULL;
    tcpSocket = new QTcpSocket(this);
    QString asa="192.168.1.102";
    tcpSocket->connectToHost(QHostAddress(asa),2222);
    connect(tcpSocket,&QTcpSocket::connected,[=](){
        tcpSocket->write("1111111");
        qDebug() <<qwe;

    });

    connect(tcpSocket,&QTcpSocket::readyRead,
            [=]() mutable
    {

        QByteArray array2=tcpSocket->readAll();//取

        if(array2.toInt()==11){
            sf-=10;
            QWidget::repaint();
        }
        if(array2.toInt()==22){
            sf+=10;
            QWidget::repaint();
        }
        if(array2.toInt()==33){
            se-=10;
            QWidget::repaint();
        }
        if(array2.toInt()==44){
            se+=10;
            QWidget::repaint();
        }

    });

}
void ww001::keyPressEvent(QKeyEvent *e)   //键盘移动
{
    switch(e->key()){
        case Qt::Key_W :sb-=10; tcpSocket->write("11");  break;
        case Qt::Key_S :sb+=10; tcpSocket->write("22");  break;
        case Qt::Key_A :sa-=10; tcpSocket->write("33");  break;
        case Qt::Key_D :sa+=10; tcpSocket->write("44");  break;
    }
    QWidget::repaint();
}
void ww001::paintEvent(QPaintEvent *)//paintEvent函数由系统自动调用
{
    paint=new QPainter;
    paint->begin(this);
    paint->setPen(QPen(Qt::blue,4,Qt::SolidLine)); //设置画笔形式
    paint->drawRect(sa,sb,100,100);

    paint->setPen(QPen(Qt::red,4,Qt::SolidLine)); //设置画笔形式
    paint->drawRect(se,sf,100,100);
    paint->end();
}
