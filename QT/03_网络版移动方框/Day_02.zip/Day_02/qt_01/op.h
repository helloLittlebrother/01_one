#ifndef OP_H
#define OP_H
#include<QTcpSocket>
#include <QWidget>

class op : public QWidget
{
    Q_OBJECT
public:
    explicit op(QWidget *parent = nullptr);
private:
    QTcpSocket *tcpSocket;
signals:

};

#endif // OP_H
