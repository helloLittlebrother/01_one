#ifndef WIDGET_H
#define WIDGET_H
#include"ss_001.h"
#include"ss_002.h"
#include <QWidget>
#include<QTcpServer>//监听套接字
#include<QTcpSocket>//通信套接字
class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void bianbian1(QByteArray);

private:
    ss_001* v = new ss_001() ;
    ss_002* vvv = new ss_002() ;

    QTcpServer *tcpServer;//监听套接字
    QTcpServer *tcpServer2;//监听套接字
    QTcpSocket *tcpSocket;//通信套接字
    QTcpSocket *tcpSocket2;//通信套接字
signals:
    void bian001(QByteArray);
    void zhubian001(QByteArray);
protected:
    void run();
};
#endif // WIDGET_H
