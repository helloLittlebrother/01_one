#include "widget.h"
int bd = 0;
int cd=0;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    //v->start();
     //vvv->start();
//void (ss_001::*cg8)(QByteArray)=&ss_001::bian001;
     // connect(v,cg8,vvv,&ss_002::bianbian2);

    // void (ss_002::*cg9)(QByteArray)=&ss_002::bian002;
          //  connect(vvv,cg9,v,&ss_001::bianbian1);

    int aaaaa = 110;


        tcpServer = new QTcpServer (this);

        tcpServer-> listen (QHostAddress :: Any, 1111);

        tcpServer2 = new QTcpServer (this);

        tcpServer2-> listen (QHostAddress :: Any, 2222);




    connect (tcpServer, & QTcpServer :: newConnection,
        [=] () mutable
        {   bd=1;
        //qDebug() << b;
            //if(b==0){
                tcpSocket = tcpServer-> nextPendingConnection ();
                //b++;
           // }else{
               // tcpSocket2 = tcpServer-> nextPendingConnection ();
                //b++;
            //}
            // Remove the established socket



    connect(tcpSocket,&QTcpSocket::readyRead,
            [=]() mutable
    {

        QByteArray array=tcpSocket->readAll();//取
        //emit bian001(array);

        //aaaaa=array.toInt();

        qDebug() << array;
        qDebug() << bd;
        qDebug() << cd;
       // emit bian001(array);
        if(cd==1){
            tcpSocket2->write(array);//发
        }

    });



        }
        );



    connect (tcpServer2, & QTcpServer :: newConnection,
        [=] () mutable
        {   cd=1;

        qDebug() << "hhhhhhwdwa";
            //if(b==0){
                //tcpSocket = tcpServer2-> nextPendingConnection ();
                //b++;
           // }else{
                tcpSocket2 = tcpServer2-> nextPendingConnection ();
                //b++;
            //}
            // Remove the established socket



    connect(tcpSocket2,&QTcpSocket::readyRead,
            [=]() mutable
    {
 qDebug() << "hhhhhhwdwa";
        QByteArray array2=tcpSocket2->readAll();//取
        //emit bian001(array);

        //aaaaa=array.toInt();

        qDebug() << array2;
       // emit bian001(array);
        if(bd==1){
            qDebug() << aaaaa;
            tcpSocket->write(array2);//发
        }

    });



        }
        );
     //connect(tcpSocket,&QTcpSocket::bian001,this,&Widget::bianbian1);

}
void Widget::bianbian1 (QByteArray array){
int a=19;
}

Widget::~Widget()
{
}

