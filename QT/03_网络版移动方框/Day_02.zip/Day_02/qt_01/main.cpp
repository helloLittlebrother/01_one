#include "widget.h"
#include"ww001.h"
#include"ww002.h"
#include <QApplication>
#include<QTcpServer>




#include <iostream>
// 必须的头文件
#include <pthread.h>

using namespace std;

#define NUM_THREADS 5
#include <QApplication>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h >
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
     w.show();
    ww001 w1;
    w1.show();
    ww002 w2;
    w2.show();

    return a.exec();
}
