#include "ss_001.h"
#include <QThread>
#include<QDebug>
#include <synchapi.h>
#include<QHostAddress>
ss_001::ss_001(QObject *parent):QThread(parent)
{

}
void ss_001::run(){
        int aaaaa=110;
        int b=123;
        qDebug() << aaaaa;
        //监听套接字
        tcpServer=new QTcpServer(this);    //this  指定父对象，让其自动回收空间
        qDebug() << aaaaa;
        tcpServer->listen(QHostAddress::Any,8800);
        qDebug() << aaaaa;



connect(tcpServer,&QTcpServer::newConnection,
        [=]()
        {

            //取出建立好连接的套接字
            tcpSocket =tcpServer->nextPendingConnection();

            connect(tcpSocket,&QTcpSocket::readyRead,
                    [=]()
            {
                   qDebug() <<"hello";
                QByteArray array=tcpSocket->readAll();//取
qDebug() << b;
               // qDebug() << aaaaa;
               // emit bian001(array);
                tcpSocket->write(array);//发
            });
        }
        );





}
void ss_001::bianbian1(QByteArray array){
    tcpSocket->write(array);//发
}
