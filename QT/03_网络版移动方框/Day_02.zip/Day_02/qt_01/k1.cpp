
#include<QDebug>
#include <iostream>
#include <thread>
#include<windows.h>
#include<QPainter>
#include<QThread>

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<QKeyEvent>
int sa=0;
int sb=50;
int sc=300;
int sd=50;
int se=500;
int sf=500;

#include "k1.h"

k1::k1(QWidget *parent) : QWidget(parent)
{
    tcpSocket=NULL;
    tcpSocket=new QTcpSocket(this);
    QString ss="192.168.19.1";
    tcpSocket->connectToHost(ss,8800);
    int a=110;
    connect(tcpSocket,&QTcpSocket::connected,[=](){

        qDebug() <<a;
    });
}

