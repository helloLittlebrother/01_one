#include "ss01.h"

ss01::ss01(QWidget *parent) : QWidget(parent)
{

}
