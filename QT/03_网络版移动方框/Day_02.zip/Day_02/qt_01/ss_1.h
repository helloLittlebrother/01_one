#ifndef SS_1_H
#define SS_1_H

#include <QWidget>

class ss_1 : public QWidget
{
    Q_OBJECT
public:
    explicit ss_1(QWidget *parent = nullptr);

signals:

};

#endif // SS_1_H
