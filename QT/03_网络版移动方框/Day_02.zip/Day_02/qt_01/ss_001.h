#ifndef SS_001_H
#define SS_001_H

#include<QTcpServer>//监听套接字
#include<QTcpSocket>//通信套接字
#include<Qthread>

class ss_001 :public QThread
{
    Q_OBJECT
public:
    explicit ss_001(QObject *parent = nullptr);
    void bianbian1(QByteArray);
protected:
    void run();
signals:
    void bian001(QByteArray);
private:
    QTcpServer *tcpServer;//监听套接字
    QTcpSocket *tcpSocket;//通信套接字

};

#endif // SS_001_H
