#ifndef SS01_H
#define SS01_H

#include <QWidget>

class ss01 : public QWidget
{
    Q_OBJECT
public:
    explicit ss01(QWidget *parent = nullptr);

signals:

};

#endif // SS01_H
