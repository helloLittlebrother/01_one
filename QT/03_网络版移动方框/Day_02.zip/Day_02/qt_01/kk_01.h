#ifndef KK_01_H
#define KK_01_H

#include <QWidget>

namespace Ui {
class kk_01;
}

class kk_01 : public QWidget
{
    Q_OBJECT

public:
    explicit kk_01(QWidget *parent = nullptr);
    ~kk_01();

private:
    Ui::kk_01 *ui;
};

#endif // KK_01_H
