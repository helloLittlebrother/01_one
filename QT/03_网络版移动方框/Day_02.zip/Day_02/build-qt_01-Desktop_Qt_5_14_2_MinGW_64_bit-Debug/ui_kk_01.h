/********************************************************************************
** Form generated from reading UI file 'kk_01.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KK_01_H
#define UI_KK_01_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_kk_01
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;

    void setupUi(QWidget *kk_01)
    {
        if (kk_01->objectName().isEmpty())
            kk_01->setObjectName(QString::fromUtf8("kk_01"));
        kk_01->resize(400, 300);
        horizontalLayoutWidget = new QWidget(kk_01);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(150, 90, 160, 80));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);

        retranslateUi(kk_01);

        QMetaObject::connectSlotsByName(kk_01);
    } // setupUi

    void retranslateUi(QWidget *kk_01)
    {
        kk_01->setWindowTitle(QCoreApplication::translate("kk_01", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class kk_01: public Ui_kk_01 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KK_01_H
